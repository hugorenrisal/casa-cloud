# 🏠 Casa — Documento de traspaso (handoff) para continuar el desarrollo

> Este documento resume **todo** el proyecto para que un agente (p. ej. Claude Code)
> pueda continuar el desarrollo sin haber visto la conversación previa. Incluye visión,
> requisitos, decisiones tomadas, arquitectura, modelo de datos, reglas de negocio,
> estado actual, limitaciones y próximos pasos.
>
> **Código de referencia:** carpeta `casa-cloud/` (versión "nube" con servidor + base de
> datos). Es la versión viva. Las versiones anteriores (`casa-app-v2..v6.html`) son
> prototipos de iteración y **no** son la base de continuación.

---

## 1. Visión del producto

App de **gestión de tareas del hogar y planificación familiar** para familias con hijos
**adolescentes (12–18)**. Objetivos:

- Reducir la carga mental de los padres y las discusiones.
- Motivar a los adolescentes con un sistema **justo, transparente y autónomo** (gamificación
  estilo fintech/RPG, sin infantilizar).
- Principio rector: **transparencia absoluta**. "Lo que no está en la app, no existe". El
  sistema actúa como **árbitro neutral**.

**No** mueve dinero real: solo **calcula** cuánto debería entregar el padre a cada hijo.

### Roles
- **Padre/madre (admin):** organiza tareas, valida, configura economía. Usa un **dashboard
  de escritorio** (ordenador).
- **Hijo (usuario final):** ve sus tareas, su monedero y su nivel; marca tareas; usa el
  mercado. Usa una **app móvil** sencilla.

---

## 2. Módulos y reglas de negocio (LO MÁS IMPORTANTE)

### 2.1 Dos tipos de tareas

**Tareas FIJAS** (la base de la paga):
- Lista **única y común a todos los hijos** (las define el padre; mismas para todos).
- Cada una tiene **frecuencia**: `daily` (diaria, p. ej. hacer la cama) o `weekly`
  (semanal, p. ej. poner una lavadora). El padre lo cambia con un interruptor.
- Seguimiento **semanal** (lunes–domingo), se reinicia cada semana.
- **Diarias:** 7 "unidades" (una por día). El hijo marca cada día con un toque. **No** pasan
  por validación del padre (auto-reporte; validar 7 días × N tareas × M hijos es inviable).
- **Semanales:** 1 unidad. El hijo marca "Hecha" y **el padre valida** (aprobar/rechazar/vencida).

**Tareas ADICIONALES** (dinero extra):
- Catálogo con **peso de esfuerzo en puntos** (XP). Ej.: baño=40, mesa=5.
- Se **reparten automáticamente por peso** entre los hijos (ver algoritmo 2.3).
- El hijo las marca "Hecha" → el padre valida.

### 2.2 Modelo de dinero (reglas exactas, ya implementadas y probadas)

- Hay una **paga fija** (`fixedPay`, configurable, **por semana**).
- Hay **dinero extra** por tareas adicionales: `puntos × rate` (`rate` = € por punto).
- Reglas sobre el **ratio de cumplimiento de tareas fijas** (unidades aprobadas/hechas ÷
  unidades totales de la semana):
  - **ratio ≥ 0.75** → el hijo **cobra la paga fija** (`fixedPay`).
  - **ratio = 1.00 (100%)** → además **desbloquea** poder ganar con las adicionales.
  - **ratio < 0.75** → **pierde** la paga fija.
  - Si 0.75 ≤ ratio < 1 → cobra fija pero las adicionales quedan **bloqueadas**.
- `money(childId) = { ratio, fixedEarned, extraEarned, total, canExtra }`.
- ⚠️ **Decisión a revisar:** la paga fija pasó a **semanal** (encaja con diarias/semanales),
  pero las adicionales y el nivel siguen siendo **mensuales**. El "total" que muestra el
  panel mezcla fija-semanal + extra-mensual. Está etiquetado, pero conviene unificar el
  periodo en el futuro.

### 2.3 Algoritmo de reparto justo (adicionales)

- Reparte **carga de esfuerzo (puntos), no número de tareas**.
- Heurístico **LPT (Longest Processing Time first)**: ordena tareas de mayor a menor peso y
  asigna cada una al hijo con **más margen** respecto a su objetivo.
- **Disponibilidad** por hijo (`load`): `normal`=1, `reducida`=0.6, `minima`=0.3. El objetivo
  de cada hijo es proporcional a su disponibilidad.
- (En versiones locales previas existía además una "memoria de equidad" β entre semanas para
  compensar a quien cargó de más; **se simplificó/retiró** de la versión actual para reducir
  complejidad. Documentado por si se quiere reintroducir.)

### 2.4 Niveles / XP

- **Puntos del mes** = `fixedApprovedUnits×2 + extraPointsApproved + marketBountyNet` (clamp ≥0).
- Nivel = `floor(puntos/100)+1`; progreso = `puntos % 100`.
- **Se reinician el día 1 de cada mes** (atado a la fecha real). El mes anterior se archiva
  en `history` y se muestra como comparación. El propósito: que el nivel represente "cuánto
  has trabajado este mes".

### 2.5 Mercado de tareas (P2P entre hermanos)

Un hijo puede poner en el mercado una **tarea adicional suya** (estado `pending`):
- **Ofreciendo puntos** a quien la haga, y/o **aceptando trueque**.

Acciones de otros hijos sobre un anuncio del tablón:
- **"Me la quedo" (take):** cierre **directo** (el vendedor ya puso precio). La tarea pasa al
  comprador; si hay puntos ofrecidos, se registran como `bounty`.
- **"Ofrecer trueque":** el ofertante da una tarea suya a cambio (+ opcionalmente **pide
  puntos** de compensación). Crea una **oferta** que el **vendedor acepta o rechaza**. Al
  aceptar, se intercambian las dos tareas (`memberId`) y la compensación se registra como
  `bounty` sobre la tarea del vendedor.

**Economía del mercado (regla clave, ya probada):**
- Cambiar una tarea de manos mueve quién la hace → **puntos de esfuerzo y dinero** van a
  quien la completa y se la aprueban (automático vía `memberId`).
- Las **primas (`bounty`) en puntos** afectan a los **puntos del mes (nivel/premios), NO al
  dinero**. Se aplican **solo cuando la tarea se aprueba** (si vence, no se paga: no hay
  forma de cobrar por trabajo no hecho).
- `marketBountyNet(childId)` = suma de `bounty.points` donde `to===child` menos donde
  `from===child`, **solo sobre extras `approved`**.
- ⚠️ **Decisiones a revisar:** (a) "Me la quedo" es inmediato (sin confirmación del vendedor);
  (b) las primas afectan al nivel pero no al dinero. Ambas son ajustables.

### 2.6 Menús

- Base de platos editable (`dishes`) + selector por día + botón "generar semana" (rellena
  `menu` aleatoriamente desde la base). **Sin lista de la compra** (descartado por ahora).

### 2.7 Recompensas / premios

- `rewards`: lista de premios con coste en puntos y tipo (Tiempo/Privilegio…). El hijo
  "canjea" (flujo de solicitud; la aprobación física la decide el padre). Es **preliminar**:
  falta el editor completo de incentivos con stock/frecuencia y el flujo de aprobación de
  canje que se describió en los requisitos originales.

### 2.8 Rachas y logros

- `streak` por hijo (contador de días; actualmente valores de ejemplo, **no** se calcula
  automáticamente todavía — pendiente).
- Logros/insignias: rejilla con condiciones simples (primera tarea, racha, 100 pts, etc.).

---

## 3. Estado actual del desarrollo

**Versión viva: "nube" (`casa-cloud/`).** Es un servidor Node/Express que sirve una SPA y
guarda **un estado familiar central compartido** por todos los dispositivos.

### Qué está hecho y PROBADO
- ✅ App completa de dos vistas (dashboard padre + móvil hijo) con todos los módulos de §2.
- ✅ Reglas de dinero, reparto por peso, niveles con reinicio mensual, mercado P2P, frecuencia
  diaria/semanal: **probadas numéricamente** (Node) y en ejecución (jsdom).
- ✅ Sincronización entre dispositivos: **probada en navegador real (Chromium/Playwright) con
  dos dispositivos**, sincronizando en **ambos sentidos** (padre genera → móvil lo ve; hijo
  marca → padre lo recibe), **sin errores de JS**.
- ✅ Almacenamiento en **archivo local** (modo por defecto sin BD): probado con servidor real
  (curl) y navegador.
- ✅ Endpoints de **copia de seguridad** (export/import JSON) y botones en el dashboard.

### Qué está escrito pero NO probado end-to-end todavía (⚠️ verificar)
- ⚠️ **Ruta de PostgreSQL/Neon** (`storage.js` modo `pg`): el código está escrito y `pg`
  instalado, pero **no se ha ejecutado contra un Postgres real** en esta sesión. **Primer
  encargo recomendado para Claude Code: levantar un Postgres local (o Neon), exportar
  `DATABASE_URL` y verificar GET/PUT/backup/restore por esa ruta.**

---

## 4. Arquitectura técnica

### Stack
- **Backend:** Node.js + Express (`server.js`). Sirve `public/` y expone una API REST.
- **Frontend:** **SPA de un solo archivo** `public/index.html` (CSS + JavaScript vanilla
  inline, sin framework ni build). Render por strings de plantilla y `innerHTML`.
- **Almacenamiento:** `storage.js` — abstracción con dos modos:
  - `pg`: PostgreSQL (Neon) si existe `process.env.DATABASE_URL`. Tabla `app_state(id INT PK,
    data JSONB)`, fila única `id=1`. SSL `rejectUnauthorized:false` (requerido por Neon).
  - `file`: `data.json` local si no hay `DATABASE_URL` (para desarrollo).
- **Sin framework de build, sin TypeScript.** Todo es JS plano para minimizar fricción.

### Estructura de ficheros (`casa-cloud/`)
```
casa-cloud/
  server.js            API Express + semilla (seed) + endpoints
  storage.js           capa de almacenamiento (pg | file)
  package.json         deps: express, pg
  .gitignore           node_modules/, data.json
  GUIA-INSTALACION.md  guía de despliegue para el usuario final (no técnico)
  public/
    index.html         TODA la app cliente (estilos + lógica + vistas)
```

### Sincronización (cliente)
- Estado central en el servidor. El **rol** (padre o qué hijo) es **local a cada dispositivo**
  (`localStorage` clave `casa_role_v1`).
- `bootstrap()`: `GET /api/state` → `S`; `ensureShape()`; si no hay rol local → pantalla
  **"¿quién eres?"** (identity picker); luego `render()` + `startPolling()`.
- **Guardado:** `Store.write(S)` → `PUT /api/state` con **debounce de 250 ms**; marca
  `_lastSent`.
- **Sondeo (polling):** cada **4 s** `GET /api/state`; si el estado remoto difiere del local
  (ignorando `view`/`profile`), lo adopta preservando el rol local y re-renderiza. Se salta
  si han pasado <1500 ms desde el último guardado propio (evita pisar el cambio recién enviado).
- Indicador de conexión (puntito verde/rojo) en la barra superior.

### API (server.js)
| Método | Ruta | Función |
|---|---|---|
| GET | `/api/state` | Lee el estado (si vacío, siembra y devuelve `seed()`) |
| PUT | `/api/state` | Guarda el estado completo (valida que tenga `members` y `fixedTasks`) |
| POST | `/api/reset` | Reinicia a la familia de ejemplo |
| GET | `/api/backup` | Descarga el estado como archivo JSON (copia de seguridad) |
| POST | `/api/restore` | Restaura el estado desde un JSON |

---

## 5. Modelo de datos (objeto `S`, persistido como JSON/JSONB)

```js
{
  view: "desk" | "mob",           // controla qué interfaz se muestra (local por dispositivo)
  profile: "parent" | <childId>,  // identidad del dispositivo (local)
  deskTab, mobTab,                // pestaña activa en cada vista
  currentMonth: "YYYY-MM",        // ciclo mensual (niveles, extras)
  currentWeek:  "YYYY-Www",       // ciclo semanal (tareas fijas)
  rate: 0.05,                     // € por punto (adicionales)
  fixedPay: 8,                    // € de paga fija POR SEMANA (si ratio≥0.75)

  members: [{ id, name, role:"parent"|"child", color, load:"normal"|"reducida"|"minima" }],

  fixedTasks: [{ id, name, icon, freq:"daily"|"weekly" }],   // lista común a todos
  extraTasks: [{ id, name, points, icon }],                  // catálogo de adicionales

  // Seguimiento SEMANAL de fijas, por hijo y por tarea:
  fixedState: {
    [childId]: {
      [taskId]: { days:[7 booleanos] }        // si la tarea es daily
               | { status:"pending"|"submitted"|"approved"|"late" } // si es weekly
    }
  },

  // Asignaciones de adicionales del MES:
  extras: [{
    id, taskId, memberId,
    status:"pending"|"submitted"|"approved"|"late",
    listed?: boolean,                          // true si está publicada en el mercado
    bounty?: { points, from:<childId>, to:<childId> }  // prima de mercado (se aplica al aprobar)
  }],
  generated: boolean,             // si ya se "generó el mes"

  monthPoints: { [childId]: n },  // VESTIGIAL: los puntos se calculan en vivo; limpiar
  streak: { [childId]: n },       // contador de días (de momento no se autocalcula)
  history: { [monthKey]: { points:{ [childId]:n } } },  // archivo de meses anteriores

  dishes: [string],
  menu: { Lun, Mar, "Mié", Jue, Vie, "Sáb", Dom : <dish> },
  rewards: [{ id, title, cost, type }],

  // MERCADO:
  listings: [{ id, sellerId, assignmentId, taskId, pointsOffered, acceptsTrade, note,
               status:"open"|"closed"|"cancelled", createdAt }],
  offers:   [{ id, listingId, bidderId, offeredAssignmentId, offeredTaskId, pointsAsked,
               status:"pending"|"rejected", createdAt }],
  marketLog:[{ kind:"take"|"trade", taskId, giveTaskId?, from, to, points, at }],
}
```

### Funciones clave en `public/index.html` (lógica)
- `weekKey(d)`, `monthKey(d)` — claves ISO de semana/mes.
- `rollover()` — reinicio **mensual** (archiva `monthPoints`, resetea extras/mercado/generated).
- `ensureWeek()` / `initFixedWeek()` / `ensureFixedShape()` — reinicio **semanal** de fijas y
  saneado de forma del estado (nuevos hijos/tareas/cambios de frecuencia).
- `generateMonth()` — inicializa la semana de fijas y reparte adicionales por peso (LPT).
- `fixedUnits/fixedApprovedUnits/fixedTotalUnits/fixedRatio` — cumplimiento por unidades.
- `money(childId)`, `monthPoints(childId)`, `levelOf(childId)`, `marketBountyNet(childId)`.
- Mercado: `publishListing, cancelListing, takeListing, submitTradeOffer, acceptOffer,
  rejectOffer`.
- Cliente/sync: `bootstrap, render, renderDesk, renderMob, renderIdentityPicker,
  startPolling, rememberRole, ensureShape, downloadBackup, restoreBackup, resetAll`.
- `ensureShape()` — **importante**: rellena campos por defecto y migra estados antiguos
  (borra `swaps`/`fixedInstances` legacy). Tiene guarda `if(!S) return`.

---

## 6. Interfaz y diseño

### Dos vistas
- **Escritorio (padre):** barra lateral + secciones Resumen, Tareas fijas, Adicionales,
  Validar, Menús, Economía. KPIs, tablas, "balanza de esfuerzo".
- **Móvil (hijo):** navegación inferior por pestañas: Inicio (monedero/nivel/tareas), Mercado,
  Logros, Menú, Premios.
- La interfaz mostrada la decide `S.view` (no solo el ancho). ⚠️ Hay **media queries legacy**
  (`@media 861px` con `.desk`/`.mob`) heredadas de la fase de demostración que ya **no** son
  la fuente de verdad (gana el `display` inline que pone `render()`). **Recomendado limpiarlas**
  para evitar confusión.

### Sistema visual ("hogar soleado", cálido y familiar)
- **Fuentes:** Fredoka (títulos y números, vía `--num`) + Nunito (cuerpo). Google Fonts.
- **Paleta (variables CSS):** `--bg:#fef6ea` (crema), `--accent:#ff7a59` (coral, acción),
  `--sun:#ffc24b`, `--green:#2fae73`, `--amber:#f59331`, `--red:#ef5b5b`, `--cyan:#2f9fd0`,
  `--violet:#8b6fd6`. Colores de hijos: Ana `#e0588f`, Leo `#2f9fd0`, Mía `#2fae73`.
- Tarjetas blancas con sombras cálidas, esquinas muy redondeadas, micro-animaciones de entrada.
- Iconos de tarea con **emoji** (decisión deliberada para calidez/usabilidad familiar).

---

## 7. Decisiones de diseño tomadas (que el usuario puede querer revisar)

1. **Paga fija = semanal**, adicionales/nivel = mensual (periodos mezclados en el total).
2. **Tareas diarias auto-reportadas** (sin validación del padre); solo se validan las
   semanales y las adicionales.
3. **Primas del mercado afectan al nivel, no al dinero.**
4. **"Me la quedo" es inmediato** (sin confirmación del vendedor); los trueques sí se confirman.
5. **Puntos por unidad de fija = 2** (calibrado para no inflar niveles con las casillas diarias).
6. **Sin "memoria de equidad" β** entre semanas en la versión actual (se simplificó).

---

## 8. Limitaciones conocidas y deuda técnica (LEER antes de seguir)

- 🔴 **Concurrencia "último que escribe gana":** se guarda el **estado completo** en cada PUT.
  Si dos dispositivos editan dentro de la misma ventana de ~4 s, uno puede **pisar** al otro.
  Es la mayor debilidad arquitectónica. Mejora recomendada: **endpoints/acciones granulares**
  (p. ej. `POST /api/action {type, payload}`) o fusión optimista, en vez de blob completo.
- 🔴 **Sin autenticación:** cualquiera con el enlace entra y elige rol. No hay cuentas ni
  contraseñas. No hay separación por familia (es **monofamiliar**: un único estado global).
- 🟠 **Sincronización por polling (4 s):** sencilla pero no instantánea y algo "chatty".
  Considerar **SSE o WebSocket** para tiempo real.
- 🟠 **Todo el cliente en un único `index.html`** (CSS+JS inline, ~muchos KB). Para escalar el
  desarrollo conviene **modularizar** (separar CSS, lógica, vistas; quizá adoptar un framework
  ligero o un bundler).
- 🟠 **`seed()` duplicada:** existe en el servidor (autoritativa) y, muerta, en el cliente.
  Eliminar la del cliente.
- 🟠 **Campo `monthPoints` en el estado es vestigial** (los puntos se calculan en vivo). Limpiar.
- 🟠 **`streak` no se autocalcula** (valores de ejemplo). Implementar lógica de rachas real.
- 🟠 **Render free duerme** el servidor a los 15 min (~1 min en despertar). **Neon free**
  permanente pero con límites (ver §10).
- 🟢 **Validación de entrada mínima** en la API (solo comprueba `members`/`fixedTasks`).
  Reforzar si se añade multiusuario.

---

## 9. Requisitos originales que faltan por desarrollar (del brief inicial)

- **Editor de incentivos completo** (padre): título, tipo (monetario/tiempo de pantalla/
  privilegios/regalos), coste, **límites de stock/frecuencia**, interruptor on/off.
- **Flujo de aprobación de canje:** cuando un hijo canjea, el padre recibe notificación para
  **aprobar/denegar** antes de descontar puntos.
- **Validación de tareas con prueba** (foto/checklist) — hoy es confirmación manual.
- **Notificaciones push** (vencimientos, canjes, validaciones).
- **Penalizaciones automáticas por vencimiento** con cron (hoy el padre marca "vencida" a mano).
- (Opcional, descartado de momento) **lista de la compra** desde el menú.

---

## 10. Despliegue (contexto para el usuario; entorno objetivo)

- **Usuario final:** Windows en el ordenador; hijos con **Android e iPhone** (mezcla).
- **Sin terminal.** Receta acordada:
  1. Subir `casa-cloud/` a **GitHub** (arrastrar y soltar por la web).
  2. Crear **Web Service** en **Render** (plan Free; runtime Node; build `npm install`, start
     `npm start`).
  3. Crear base de datos **Neon** (Postgres gratuito **permanente**) y pegar su cadena de
     conexión en Render como variable de entorno **`DATABASE_URL`**.
  4. Abrir la URL de Render en ordenador (elige "padre") y en cada móvil (elige su hijo);
     "Añadir a pantalla de inicio" para que parezca app.
- La `GUIA-INSTALACION.md` ya cubre GitHub + Render + instalación en dispositivos. **Falta
  añadirle la sección de Neon** (crear cuenta → crear proyecto Postgres → copiar la connection
  string "pooled" → pegarla como `DATABASE_URL` en Render → redeploy). **Tarea pendiente.**

### ⚠️ Datos a verificar (cambian con el tiempo — verificar en la web oficial antes de afirmar)
- Render Free: **se duerme a los 15 min**; **PostgreSQL gratuito de Render caduca a los 30
  días** (por eso usamos **Neon**, no la BD de Render).
- Neon Free: ~0,5 GiB, permanente, pero límites pueden cambiar.
- Precios/planes (Render de pago ~6–7 $/mes) observados en mayo 2026; **reverificar**.

---

## 11. Próximos pasos sugeridos (orden recomendado para Claude Code)

1. **Verificar la ruta PostgreSQL** (`DATABASE_URL`) de extremo a extremo (GET/PUT/backup/
   restore) contra Neon o un Postgres local. Es lo único escrito-pero-no-probado.
2. **Completar la guía** con los pasos de Neon.
3. **Robustez de concurrencia:** migrar de "PUT del estado completo" a **acciones granulares**
   en el servidor (mover ahí la lógica de negocio que hoy vive en el cliente). Esto también
   prepara el terreno para autenticación y multifamilia.
4. **Autenticación básica** (al menos un PIN/clave por familia; idealmente cuentas por miembro).
5. **Tiempo real** (SSE/WebSocket) en lugar de polling.
6. **Modularizar** el frontend (separar de `index.html`).
7. Implementar **rachas reales**, **editor de incentivos con stock**, **aprobación de canjes**,
   **notificaciones** y **penalizaciones por cron**.
8. Revisar las **decisiones de §7** con el usuario (periodo de la paga, primas↔dinero, etc.).

---

## 12. Notas legales / de cumplimiento (no es asesoría jurídica)

- Trata datos de **menores** → revisar **RGPD** con un profesional antes de publicar. El diseño
  actual guarda **datos mínimos** a propósito (alias, rol, disponibilidad; nada sensible).
- **No** se procesa dinero real (solo cálculo orientativo), lo que evita normativa de dinero
  electrónico.

---

## 13. Cómo continuar (para Claude Code)

- La base de trabajo es **`casa-cloud/`**. Arranque local: `npm install` y `npm start`
  (modo archivo, sin `DATABASE_URL`). Para modo BD: exportar `DATABASE_URL` y arrancar.
- **Toda la lógica de negocio del cliente** está en el `<script>` inline de
  `public/index.html`. El servidor solo persiste el blob y sirve estáticos (de momento).
- Hay un patrón de pruebas usado en el desarrollo que conviene mantener: **probar la lógica
  con Node** (funciones puras), **render con jsdom**, y **flujo real con Playwright/Chromium**
  (dos contextos = dos dispositivos) antes de dar nada por terminado.
- Mantener el principio del proyecto: **honestidad sobre lo que está probado vs. no**, y
  **transparencia** como valor de producto.
