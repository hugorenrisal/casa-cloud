# 🏠 Casa — Guía para poner la app en marcha

Esta guía te lleva, paso a paso y **sin usar la terminal**, desde el archivo que tienes
hasta tener la app funcionando en tu ordenador y en los móviles de tus hijos, todos
conectados a la misma "casa".

Tiempo aproximado: **15–20 minutos**, una sola vez.

---

## Antes de empezar: ¿por qué hace falta esto?

Para que lo que tus hijos marcan en su móvil aparezca en tu ordenador, los datos tienen
que vivir en un **servidor en internet** al que se conecten todos los dispositivos. No
puede estar solo en tu ordenador. Por eso vamos a:

1. Subir el código a **GitHub** (un sitio donde se guarda el código, gratis).
2. Conectarlo a **Render** (un servicio que pone el servidor online, con plan gratis).
3. Abrir la dirección que te dé Render en el ordenador y en los móviles.

> **Aviso honesto sobre el plan gratuito de Render:** el servidor gratuito **se "duerme"
> tras 15 minutos sin uso** y tarda **entre 30 y 60 segundos en despertar** la primera vez
> que alguien lo abre después de un rato. No es un fallo: es normal en el plan gratis. Si
> os molesta, Render tiene un plan de pago (alrededor de 7 $/mes) que lo mantiene siempre
> despierto. *(Precio observado en mayo de 2026; puede cambiar — compruébalo en su web.)*

---

## PARTE 1 — Crear el código en GitHub

1. Entra en **https://github.com** y crea una cuenta gratuita (si no la tienes). Solo pide
   correo, usuario y contraseña.
2. Una vez dentro, arriba a la derecha pulsa el **"+"** → **"New repository"**.
3. Ponle un nombre, por ejemplo `casa-tareas`. Déjalo en **Public** (es lo más sencillo;
   no contiene datos personales). Pulsa **"Create repository"**.
4. En la página que aparece, busca el enlace que dice **"uploading an existing file"**
   (está en el texto "Get started by … uploading an existing file"). Púlsalo.
5. **Arrastra y suelta** ahí dentro el contenido de la carpeta `casa-cloud` que te he
   preparado: los archivos `server.js`, `package.json`, `.gitignore` y **la carpeta
   `public`** (con `index.html` dentro).
   - Importante: sube los archivos que están **dentro** de `casa-cloud`, no la carpeta
     `casa-cloud` en sí. En GitHub deben quedar `server.js`, `package.json` y la carpeta
     `public` en la raíz.
6. Abajo pulsa el botón verde **"Commit changes"**. Ya tienes el código en GitHub.

---

## PARTE 2 — Poner el servidor online con Render

1. Entra en **https://render.com** y pulsa **"Get Started"**. Regístrate eligiendo
   **"Sign in with GitHub"** (así conecta solo, sin configurar nada).
2. Autoriza a Render a ver tus repositorios cuando te lo pida.
3. En el panel de Render, pulsa **"New +"** (arriba) → **"Web Service"**.
4. Te mostrará tus repositorios de GitHub. Busca `casa-tareas` y pulsa **"Connect"**.
5. Render rellena casi todo solo. Comprueba/ajusta estos campos:
   - **Name:** lo que quieras (será parte de la dirección web). Ej. `mi-casa`.
   - **Region:** la más cercana (por ejemplo, Frankfurt si estás en España).
   - **Branch:** `main` (viene puesto).
   - **Runtime / Language:** debe detectar **Node** solo.
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** elige **"Free"**.
6. Pulsa **"Create Web Service"** (o "Deploy Web Service").
7. Espera 2–4 minutos mientras Render instala y arranca. Cuando veas **"Live"** (en verde)
   y un mensaje tipo *"Casa escuchando en el puerto…"* en los registros, está listo.
8. Arriba verás la **dirección de tu app**, algo como
   `https://mi-casa.onrender.com`. **Esa es tu casa.** Cópiala.

> Si en algún momento Render te pidiera una tarjeta para crear el "Web Service", prueba a
> cerrar sesión y volver a entrar, o escríbeme y te doy una alternativa equivalente
> (Railway o similar). Según lo que verifiqué, el plan gratuito de Render **no debería**
> pedir tarjeta, pero algún usuario lo ha reportado y prefiero avisarte.

---

## PARTE 3 — Abrir la app en cada dispositivo

La misma dirección (`https://mi-casa.onrender.com`) se abre en **todos** los aparatos.
La primera vez, cada dispositivo te preguntará **quién lo usa** (padre o qué hijo) y lo
recordará.

### En tu ordenador (Windows) — el dashboard
1. Abre la dirección en **Chrome** o **Edge**.
2. Elige **"Soy padre / madre"**.
3. (Opcional, para tenerlo como app) En Chrome: menú **⋮** (arriba derecha) →
   **"Guardar y compartir"** → **"Instalar página como aplicación…"**. En Edge: menú
   **…** → **"Aplicaciones"** → **"Instalar este sitio como una aplicación"**.
   Quedará con su icono y se abrirá en su propia ventana, como un programa normal.

### En el móvil de cada hijo
1. Abre la dirección en el navegador del móvil.
2. Que elija **su nombre**.
3. Para tenerla como app en la pantalla de inicio:
   - **Android (Chrome):** menú **⋮** → **"Añadir a pantalla de inicio"** → "Añadir".
   - **iPhone (Safari):** botón **Compartir** (el cuadrado con la flecha) →
     **"Añadir a pantalla de inicio"** → "Añadir".
4. A partir de ahí, abren el icono y entran directos a sus tareas.

---

## Cómo se usa, en resumen

- **Tú (ordenador):** creas las tareas fijas (diarias o semanales) y las adicionales,
  pulsas **"Generar mes"**, y validas las tareas semanales y adicionales que te llegan.
- **Cada hijo (móvil):** marca sus tareas diarias día a día, marca las semanales/adicionales
  como hechas (te llegan a ti para validar) y usa el mercado entre hermanos.
- Todo se sincroniza solo cada pocos segundos. El puntito verde arriba indica que hay
  conexión con el servidor (se pone rojo si se pierde).

---

## Cosas que conviene saber (sin sorpresas)

- **El primer acceso del día puede tardar hasta ~1 minuto** mientras el servidor gratuito
  despierta. Después va fluido.
- **Los datos viven en el servidor mientras el servicio está activo.** En el plan gratuito,
  si Render reinicia el servicio (por ejemplo, tras un nuevo despliegue), el estado puede
  reiniciarse. Para uso de prueba está bien; para uso serio y duradero, el siguiente paso
  técnico sería conectar una base de datos (te lo puedo preparar cuando quieras).
- **No hay contraseñas.** Cualquiera con el enlace puede entrar y elegir un rol. Como no
  hay datos personales ni dinero real, el riesgo es bajo, pero si quieres que el enlace no
  sea adivinable, ponle a tu servicio en Render un nombre poco obvio.
- **No se mueve dinero real:** la app solo calcula cuánto deberías dar a cada hijo.

---

## Si algo no funciona

- **"No se pudo conectar con el servidor":** espera un minuto (servidor despertando) y
  recarga. Si sigue, entra en Render y comprueba que el servicio está **"Live"**.
- **Quiero empezar de cero:** en el navegador del ordenador, en la barra de direcciones,
  añade `/api/reset` al final de tu dirección y pulsa Enter una vez. Volverá a la familia
  de ejemplo. (Es un atajo; bórralo de la barra después.)
- **Cambiar de usuario en un dispositivo:** botón **"Cambiar"** arriba a la derecha.
